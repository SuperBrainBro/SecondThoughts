# GODOT-2D-Top-Down-basic-player-movement
A basic and smooth 2D Top-Down movement script for a player
